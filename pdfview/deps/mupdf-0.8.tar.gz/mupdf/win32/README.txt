This MSVC project needs both the thirdparty and pregen sources to be in place.
